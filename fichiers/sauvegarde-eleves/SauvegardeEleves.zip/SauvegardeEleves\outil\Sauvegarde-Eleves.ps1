﻿# Sauvegarde du travail des élèves
# Copie les dossiers choisis (serveur de l'établissement) vers la clé USB où se trouve cet outil.
# La première fois tout est copié ; ensuite seuls les fichiers nouveaux ou modifiés sont recopiés.
# -Rapide : lance directement la sauvegarde avec les dossiers déjà enregistrés, sans fenêtre.

param([switch]$Rapide)

$ErrorActionPreference = 'Stop'
$FichierConfig = Join-Path $PSScriptRoot 'config.json'
$Lecteur = [IO.Path]::GetPathRoot($PSScriptRoot)   # ex. "E:\" : la lettre de la clé change d'un PC à l'autre

# ---------- Configuration ----------

function Lire-Config {
    $c = $null
    if (Test-Path -LiteralPath $FichierConfig) {
        try { $c = Get-Content -LiteralPath $FichierConfig -Raw -Encoding UTF8 | ConvertFrom-Json } catch { }
    }
    $sources = @()
    if ($c -and $c.Sources) {
        foreach ($s in $c.Sources) {
            $nom = if ($s.Nom) { [string]$s.Nom } else { Nom-Destination ([string]$s.Chemin) }
            $sources += [pscustomobject]@{ Chemin = [string]$s.Chemin; Nom = $nom; Actif = [bool]$s.Actif }
        }
    }
    $dest = if ($c -and $c.Destination) { [string]$c.Destination } else { 'Sauvegarde_Eleves' }
    [pscustomobject]@{ Sources = $sources; Destination = $dest }
}

function Ecrire-Config($Cfg) {
    $Cfg | ConvertTo-Json -Depth 4 | Set-Content -LiteralPath $FichierConfig -Encoding UTF8
}

# Destination relative = sur la clé (quelle que soit sa lettre) ; absolue = ailleurs
function Chemin-Destination($Dest) {
    if ([IO.Path]::IsPathRooted($Dest)) { $Dest } else { Join-Path $Lecteur $Dest }
}

# Chemin utilisable par robocopy (pas de "\" final, "P:\" devient "P:\.")
function Chemin-Robocopy($Chemin) {
    $c = $Chemin.TrimEnd('\')
    if ($c.EndsWith(':')) { $c += '\.' }
    $c
}

# Sous-dossier de destination : le chemin réseau complet, sans lettre de lecteur.
# "S:\3 E\Commun\TECHNO" (S: = \\srv-college\classes) -> "srv-college\classes\3 E\Commun\TECHNO"
# Les lettres changent d'un collège à l'autre, le nom du serveur non : pas de mélange entre établissements.
# Calculé à l'ajout du dossier (quand le réseau est là) puis mémorisé.
function Nom-Destination($Chemin) {
    $c = $Chemin.TrimEnd('\')
    if ($c -match '^([A-Za-z]):(.*)$') {
        $lettre = $Matches[1]; $reste = $Matches[2]
        $disque = $null
        try { $disque = Get-CimInstance Win32_LogicalDisk -Filter "DeviceID='${lettre}:'" } catch { }
        if ($disque -and $disque.ProviderName) { $c = $disque.ProviderName.TrimEnd('\') + $reste }
        else { $c = "Lecteur $lettre" + $reste }
    }
    $c = $c.TrimStart('\')
    $invalides = [IO.Path]::GetInvalidFileNameChars()
    $parties = foreach ($p in ($c -split '\\' | Where-Object { $_ })) {
        foreach ($x in $invalides) { $p = $p.Replace([string]$x, '_') }
        $p
    }
    $parties -join '\'
}

# ---------- Copie ----------

function Copier-Dossiers {
    param($Cfg, [scriptblock]$Log, [scriptblock]$Etape)

    $destRacine = Chemin-Destination $Cfg.Destination
    $dossierJournaux = Join-Path $destRacine '_Journaux'
    New-Item -ItemType Directory -Force -Path $dossierJournaux | Out-Null

    $actifs = @($Cfg.Sources | Where-Object { $_.Actif })
    $oem = [Text.Encoding]::GetEncoding([Globalization.CultureInfo]::CurrentCulture.TextInfo.OEMCodePage)
    $debut = Get-Date
    $res = [pscustomobject]@{ Nouveaux = 0; Modifies = 0; Erreurs = 0; Ignores = 0; Journal = $null }
    $journal = New-Object Collections.Generic.List[string]
    $journal.Add("Sauvegarde du $($debut.ToString('dddd d MMMM yyyy à HH:mm'))")
    $journal.Add("Destination : $destRacine")

    $i = 0
    foreach ($s in $actifs) {
        $i++
        & $Etape $i $actifs.Count
        $src = $s.Chemin
        $dst = Join-Path $destRacine $s.Nom
        & $Log ""
        & $Log "=== [$i/$($actifs.Count)] $src  ->  $($s.Nom)"

        if (-not (Test-Path -LiteralPath $src -PathType Container)) {
            # Normal pour un dossier de l'autre établissement : on passe sans le compter comme erreur
            & $Log "  -- Non accessible depuis ce PC (autre établissement ?) : ignoré."
            $res.Ignores++
            continue
        }
        $journal.Add("")
        $journal.Add("=== $src  ->  $($s.Nom)")

        $srcRc = Chemin-Robocopy $src
        # /E sous-dossiers, /XO ne jamais écraser une copie plus récente, /FFT tolérance de date (clés FAT/exFAT),
        # /R:1 /W:1 ne pas bloquer sur un fichier ouvert, /XJ ignorer les jonctions. Rien n'est jamais supprimé sur la clé.
        $arguments = '"' + $srcRc + '" "' + $dst + '" /E /XO /FFT /R:1 /W:1 /XJ /FP /NP /NDL /NJH /NJS' +
                     ' /XF Thumbs.db desktop.ini ~$* .~lock.* *.tmp' +
                     ' /XD "$RECYCLE.BIN" "System Volume Information"'

        $psi = New-Object Diagnostics.ProcessStartInfo 'robocopy.exe', $arguments
        $psi.UseShellExecute = $false
        $psi.RedirectStandardOutput = $true
        $psi.CreateNoWindow = $true
        $psi.StandardOutputEncoding = $oem
        $p = [Diagnostics.Process]::Start($psi)

        $nouveaux = 0; $modifies = 0
        while ($null -ne ($ligne = $p.StandardOutput.ReadLine())) {
            if (-not $ligne.Trim()) { continue }
            $champs = $ligne.Split("`t") | ForEach-Object { $_.Trim() } | Where-Object { $_ }
            if ($ligne -match '^\s*\d{4}/\d{2}/\d{2}') {
                # Ligne d'erreur robocopy (fichier verrouillé, accès refusé...)
                & $Log "  !! $($ligne.Trim())"
                $journal.Add("  !! $($ligne.Trim())")
                $res.Erreurs++
            }
            elseif (@($champs).Count -ge 3) {
                $chemin = $champs[-1]
                $relatif = if ($chemin.StartsWith($srcRc, [StringComparison]::OrdinalIgnoreCase)) { $chemin.Substring($srcRc.Length).TrimStart('\') } else { $chemin }
                if ($champs[0] -match 'Nouv|New') { $etat = 'nouveau '; $nouveaux++ } else { $etat = 'modifié '; $modifies++ }
                & $Log "  + $etat $relatif"
                $journal.Add("  $etat $relatif")
            }
            else {
                & $Log "  $($ligne.Trim())"
            }
        }
        $p.WaitForExit()
        if ($p.ExitCode -ge 8) {
            & $Log "  !! Certains fichiers n'ont pas pu être copiés (code robocopy $($p.ExitCode))."
            if ($res.Erreurs -eq 0) { $res.Erreurs++ }
        }
        if ($nouveaux + $modifies -eq 0) {
            & $Log "  Rien de nouveau."
            $journal.Add("  Rien de nouveau.")
        }
        $res.Nouveaux += $nouveaux
        $res.Modifies += $modifies
    }

    $duree = [int]((Get-Date) - $debut).TotalSeconds
    $bilan = "Bilan : $($res.Nouveaux) fichier(s) nouveau(x), $($res.Modifies) modifié(s), $($res.Erreurs) problème(s), $($res.Ignores) dossier(s) non accessible(s) ici - $duree s."
    $journal.Insert(2, $bilan)
    $res.Journal = Join-Path $dossierJournaux ($debut.ToString('yyyy-MM-dd_HH\hmm-ss') + '.txt')
    $journal | Set-Content -LiteralPath $res.Journal -Encoding UTF8
    $journal | Set-Content -LiteralPath (Join-Path $destRacine '_Derniere_sauvegarde.txt') -Encoding UTF8
    & $Log ""
    & $Log $bilan
    $res
}

# ---------- Mode rapide (sans fenêtre) ----------

if ($Rapide) {
    $cfg = Lire-Config
    if (-not @($cfg.Sources | Where-Object { $_.Actif }).Count) {
        Write-Host "Aucun dossier coché. Lancez d'abord 'Sauvegarde-Eleves.bat' pour choisir les dossiers." -ForegroundColor Yellow
        exit 1
    }
    Write-Host "Sauvegarde vers $(Chemin-Destination $cfg.Destination)" -ForegroundColor Cyan
    $r = Copier-Dossiers -Cfg $cfg -Log { param($t) Write-Host $t } -Etape { param($i, $n) }
    exit ([int]($r.Erreurs -gt 0))
}

# ---------- Fenêtre ----------

Add-Type -AssemblyName System.Windows.Forms, System.Drawing
[Windows.Forms.Application]::EnableVisualStyles()

$cfg = Lire-Config
$script:chargement = $false

function Nouveau($Type, $X, $Y, $L, $H, $Texte, $Ancre = 'Top,Left') {
    $c = New-Object "Windows.Forms.$Type"
    $c.Location = New-Object Drawing.Point($X, $Y)
    $c.Size = New-Object Drawing.Size($L, $H)
    if ($null -ne $Texte) { $c.Text = $Texte }
    $c.Anchor = $Ancre
    $form.Controls.Add($c)
    $c
}

$form = New-Object Windows.Forms.Form
$form.Text = 'Sauvegarde du travail des élèves'
$form.ClientSize = New-Object Drawing.Size(740, 590)
$form.MinimumSize = New-Object Drawing.Size(640, 560)
$form.StartPosition = 'CenterScreen'
$form.Font = New-Object Drawing.Font('Segoe UI', 9.5)

$null = Nouveau Label 10 10 560 20 'Dossiers à sauvegarder (cochez ceux à copier) :'
$liste = Nouveau CheckedListBox 10 32 560 160 $null 'Top,Left,Right'
$liste.CheckOnClick = $true
$liste.HorizontalScrollbar = $true
$btnAjouter = Nouveau Button 580 32 150 32 'Ajouter un dossier…' 'Top,Right'
$btnRetirer = Nouveau Button 580 70 150 32 'Retirer' 'Top,Right'
$btnTout = Nouveau Button 580 120 150 32 'Tout cocher' 'Top,Right'
$btnRien = Nouveau Button 580 158 150 32 'Tout décocher' 'Top,Right'

$null = Nouveau Label 10 202 560 20 'Ou collez un chemin (ex. \\serveur\classes\2nde3\Travaux) :'
$txtChemin = Nouveau TextBox 10 224 560 26 $null 'Top,Left,Right'
$btnAjouterChemin = Nouveau Button 580 222 150 30 'Ajouter ce chemin' 'Top,Right'

$lblDest = Nouveau Label 10 260 560 52 '' 'Top,Left,Right'
$btnChanger = Nouveau Button 580 264 72 30 'Changer…' 'Top,Right'
$btnOuvrir = Nouveau Button 658 264 72 30 'Ouvrir' 'Top,Right'

$btnLancer = Nouveau Button 10 314 720 44 'Lancer la sauvegarde' 'Top,Left,Right'
$btnLancer.Font = New-Object Drawing.Font('Segoe UI', 11, [Drawing.FontStyle]::Bold)
$progression = Nouveau ProgressBar 10 366 720 14 $null 'Top,Left,Right'

$txtLog = Nouveau TextBox 10 388 720 150 $null 'Top,Bottom,Left,Right'
$txtLog.Multiline = $true
$txtLog.ReadOnly = $true
$txtLog.ScrollBars = 'Both'
$txtLog.WordWrap = $false
$txtLog.Font = New-Object Drawing.Font('Consolas', 9)

$btnNouveautes = Nouveau Button 10 548 260 32 'Voir les nouveautés de la dernière fois' 'Bottom,Left'
$btnJournaux = Nouveau Button 280 548 200 32 'Historique des sauvegardes' 'Bottom,Left'

function Rafraichir-Liste {
    $script:chargement = $true
    $liste.Items.Clear()
    foreach ($s in $cfg.Sources) { [void]$liste.Items.Add($s.Chemin, $s.Actif) }
    $script:chargement = $false
}

function Rafraichir-Destination {
    $d = Chemin-Destination $cfg.Destination
    $texte = "Destination : $d"
    try {
        $info = New-Object IO.DriveInfo([IO.Path]::GetPathRoot($d))
        $texte += "   (libre : {0:N1} Go)" -f ($info.AvailableFreeSpace / 1GB)
        if ($info.DriveType -ne 'Removable') {
            $texte += "`nAttention : pas une clé USB (lancez l'outil depuis la clé)."
            $lblDest.ForeColor = 'DarkRed'
        } else { $lblDest.ForeColor = 'Black' }
    } catch { }
    $lblDest.Text = $texte
}

function Ajouter-Source($Chemin) {
    $Chemin = $Chemin.Trim().Trim('"')
    if (-not $Chemin) { return }
    if (-not (Test-Path -LiteralPath $Chemin -PathType Container)) {
        [void][Windows.Forms.MessageBox]::Show("Ce dossier est introuvable :`n$Chemin", 'Dossier introuvable', 'OK', 'Warning')
        return
    }
    if ($cfg.Sources | Where-Object { $_.Chemin -eq $Chemin }) { return }
    $cfg.Sources = @($cfg.Sources) + [pscustomobject]@{ Chemin = $Chemin; Nom = (Nom-Destination $Chemin); Actif = $true }
    Ecrire-Config $cfg
    Rafraichir-Liste
}

function Ouvrir($Chemin) {
    if (Test-Path -LiteralPath $Chemin) { Start-Process explorer.exe -ArgumentList "`"$Chemin`"" }
    else { [void][Windows.Forms.MessageBox]::Show("Rien pour l'instant : lancez d'abord une sauvegarde.", 'Sauvegarde') }
}

$liste.Add_ItemCheck({
    param($sender, $e)
    if ($script:chargement) { return }
    $cfg.Sources[$e.Index].Actif = ($e.NewValue -eq 'Checked')
    Ecrire-Config $cfg
})

$btnAjouter.Add_Click({
    $dlg = New-Object Windows.Forms.FolderBrowserDialog
    $dlg.Description = "Choisissez un dossier du serveur à sauvegarder"
    if ($dlg.ShowDialog($form) -eq 'OK') { Ajouter-Source $dlg.SelectedPath }
})
$btnAjouterChemin.Add_Click({ Ajouter-Source $txtChemin.Text; $txtChemin.Clear() })

$btnRetirer.Add_Click({
    if ($liste.SelectedIndex -lt 0) { return }
    $chemin = $cfg.Sources[$liste.SelectedIndex].Chemin
    $msg = "Retirer ce dossier de la liste ?`n$chemin`n`n(Les fichiers déjà copiés sur la clé sont conservés.)"
    if ([Windows.Forms.MessageBox]::Show($msg, 'Retirer', 'YesNo', 'Question') -ne 'Yes') { return }
    $cfg.Sources = @($cfg.Sources | Where-Object { $_.Chemin -ne $chemin })
    Ecrire-Config $cfg
    Rafraichir-Liste
})

$btnTout.Add_Click({ foreach ($s in $cfg.Sources) { $s.Actif = $true }; Ecrire-Config $cfg; Rafraichir-Liste })
$btnRien.Add_Click({ foreach ($s in $cfg.Sources) { $s.Actif = $false }; Ecrire-Config $cfg; Rafraichir-Liste })

$btnChanger.Add_Click({
    $dlg = New-Object Windows.Forms.FolderBrowserDialog
    $dlg.Description = "Choisissez le dossier où ranger les copies"
    $dlg.SelectedPath = Chemin-Destination $cfg.Destination
    if ($dlg.ShowDialog($form) -ne 'OK') { return }
    $p = $dlg.SelectedPath
    # Sur la clé elle-même : on mémorise un chemin sans lettre de lecteur
    if ($p.StartsWith($Lecteur, [StringComparison]::OrdinalIgnoreCase)) {
        $p = $p.Substring($Lecteur.Length)
        if (-not $p) { $p = '.' }
    }
    $cfg.Destination = $p
    Ecrire-Config $cfg
    Rafraichir-Destination
})
$btnOuvrir.Add_Click({ Ouvrir (Chemin-Destination $cfg.Destination) })
$btnNouveautes.Add_Click({ Ouvrir (Join-Path (Chemin-Destination $cfg.Destination) '_Derniere_sauvegarde.txt') })
$btnJournaux.Add_Click({ Ouvrir (Join-Path (Chemin-Destination $cfg.Destination) '_Journaux') })

$btnLancer.Add_Click({
    if (-not @($cfg.Sources | Where-Object { $_.Actif }).Count) {
        [void][Windows.Forms.MessageBox]::Show('Cochez au moins un dossier à sauvegarder.', 'Sauvegarde')
        return
    }
    foreach ($c in $form.Controls) { if ($c -is [Windows.Forms.Button] -or $c -is [Windows.Forms.CheckedListBox]) { $c.Enabled = $false } }
    $form.Cursor = 'WaitCursor'
    $txtLog.Clear()
    try {
        $r = Copier-Dossiers -Cfg $cfg `
            -Log { param($t) $txtLog.AppendText($t + "`r`n"); [Windows.Forms.Application]::DoEvents() } `
            -Etape { param($i, $n) $progression.Maximum = $n; $progression.Value = $i - 1; [Windows.Forms.Application]::DoEvents() }
        $progression.Value = $progression.Maximum
        $msg = "Sauvegarde terminée.`n`n$($r.Nouveaux) fichier(s) nouveau(x)`n$($r.Modifies) fichier(s) modifié(s)"
        if ($r.Ignores) { $msg += "`n$($r.Ignores) dossier(s) non accessible(s) depuis ce PC (ignorés)" }
        if ($r.Erreurs) { $msg +="`n`n$($r.Erreurs) problème(s) : voir le détail dans la fenêtre." }
        [void][Windows.Forms.MessageBox]::Show($msg, 'Sauvegarde', 'OK', $(if ($r.Erreurs) { 'Warning' } else { 'Information' }))
    }
    catch {
        $txtLog.AppendText("ERREUR : $($_.Exception.Message)`r`n")
        [void][Windows.Forms.MessageBox]::Show("La sauvegarde s'est arrêtée :`n$($_.Exception.Message)", 'Erreur', 'OK', 'Error')
    }
    finally {
        foreach ($c in $form.Controls) { $c.Enabled = $true }
        $form.Cursor = 'Default'
        Rafraichir-Destination
    }
})

Rafraichir-Liste
Rafraichir-Destination
[void]$form.ShowDialog()
