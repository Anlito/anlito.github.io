@echo off
rem Sauvegarde directe des dossiers deja coches, sans ouvrir la fenetre.
title Sauvegarde du travail des eleves
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0outil\Sauvegarde-Eleves.ps1" -Rapide
echo.
pause
