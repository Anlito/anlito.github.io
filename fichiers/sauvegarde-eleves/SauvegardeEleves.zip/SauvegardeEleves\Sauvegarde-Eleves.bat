@echo off
rem Ouvre la fenetre : choix des dossiers puis sauvegarde sur la cle.
start "" powershell.exe -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File "%~dp0outil\Sauvegarde-Eleves.ps1"
